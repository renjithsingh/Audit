@echo off
setlocal
REM AuditPilot one-step launcher for Windows.
REM Creates a virtual environment on first run, installs dependencies, then starts the app.
REM If the folder is on a network share or mapped network drive (Streamlit refuses to run from those),
REM it copies itself to %LOCALAPPDATA%\auditpilot and runs from there.

pushd "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.10+ not found. Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^) and retry.
  pause
  exit /b 1
)
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"
if errorlevel 1 (
  echo Python 3.10 or newer is required.
  pause
  exit /b 1
)

REM --- Network-path check: Streamlit rejects apps whose real path is a UNC path (\\server\share\...) ---
python -c "import pathlib,sys; sys.exit(1 if str(pathlib.Path.cwd().resolve()).startswith(chr(92)*2) else 0)"
if errorlevel 1 goto :relocate
goto :local

:relocate
set "LOCALDIR=%LOCALAPPDATA%\auditpilot"
echo.
echo This folder is on a network drive or share:
echo   %CD%
echo Streamlit cannot run apps from network paths, so AuditPilot will be copied to:
echo   %LOCALDIR%
echo.
robocopy "%CD%\." "%LOCALDIR%" /E /XD .venv __pycache__ .pytest_cache /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
  echo Copy failed. Copy the auditpilot folder to a local drive such as C:\auditpilot yourself and run run.bat there.
  popd
  pause
  exit /b 1
)
popd
echo Copied. From now on, run %LOCALDIR%\run.bat directly.
echo.
call "%LOCALDIR%\run.bat"
exit /b

:local
if not exist .venv (
  echo Creating virtual environment .venv ...
  python -m venv .venv
  if errorlevel 1 (
    echo Could not create the virtual environment.
    pause
    exit /b 1
  )
)
call .venv\Scripts\activate.bat

if not exist .venv\.installed (
  echo Installing dependencies ...
  python -m pip install --upgrade pip >nul
  python -m pip install -r requirements.txt || (pause & exit /b 1)
  echo done> .venv\.installed
)

if not exist .env copy .env.example .env >nul

echo Starting AuditPilot at http://localhost:8501
python -m streamlit run app\Home.py --server.port 8501
popd
