import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # app/ on the path for "import ui"
import io
import json
from datetime import date

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import ui
from core import ai, db
from core import onboarding as ob
from core.config import ACCESS_LABEL, ACCESS_ORDER, CRIT_ORDER, TIER_COLOR, people_with_role
from core.doc_io import read_bytes
from core.generate_data import CATEGORY_NAMES, COUNTRIES
from core.planner import active_plan, generate_plan

ui.setup("Supplier onboarding", icon="🧾")
ob.seed_queue()
st.caption("Onboard a new supplier: AuditPilot checks for duplicates, reads the security questionnaire, scores "
           "risk, decides audit eligibility, frequency and scope, and lists the documents still needed — before "
           "the supplier is approved into the supplier master.")

VIEWS = ["New supplier", "Onboarding queue", "Decided"]
CERTS = {"valid": "Valid ISO 27001 / SOC 2", "expired": "Expired", "none": "None"}
K = "onb_"
SAMPLE_DIR = Path(__file__).resolve().parents[2] / "samples" / "onboarding"


# ---------------------------------------------------------------- form state
def to_state(p: dict, request_id: str | None = None) -> None:
    """Queue a payload to be loaded into the form on the next run (widgets cannot change after creation)."""
    st.session_state["onb_pending"] = (p, request_id)


def _d(v):
    if v in (None, ""):
        return None
    return v if isinstance(v, date) else date.fromisoformat(str(v)[:10])


pending = st.session_state.pop("onb_pending", None)
if pending is not None:
    p, rid = pending
    p = ob.blank(**p)
    for f, v in p.items():
        if f in ("contract_start", "contract_end", "certification_expiry"):
            v = _d(v)
        elif f in ("users_with_system_access", "contractor_headcount"):
            v = int(v or 0)
        elif f == "contract_value_inr":
            v = int(v or 0)
        st.session_state[K + f] = v
    st.session_state["onb_editing"] = rid
    st.session_state["onb_result"] = None
    st.session_state["onb_view"] = "New supplier"
if K + "legal_name" not in st.session_state:
    for f, v in ob.blank().items():
        st.session_state[K + f] = _d(v) if f in ("contract_start", "contract_end", "certification_expiry") else v

reqs = ob.list_requests()
counts = reqs.status.value_counts().to_dict() if len(reqs) else {}
c = st.columns(4)
c[0].metric("Needs data", counts.get("Needs data", 0), help="Found in a source system but not in the supplier master, or imported with missing values")
c[1].metric("Awaiting approval", counts.get("Submitted", 0))
c[2].metric("Approved", counts.get("Approved", 0))
c[3].metric("Rejected", counts.get("Rejected", 0))

view = st.radio("View", VIEWS, horizontal=True, key="onb_view", label_visibility="collapsed")
if st.session_state.get("onb_flash"):
    st.success(st.session_state.pop("onb_flash"))


# ---------------------------------------------------------------- assessment renderer
def show_assessment(a: dict, compact: bool = False) -> None:
    rec = a["recommendation"]
    (st.error if a["blockers"] else st.warning if a["missing_documents"] else st.success)(f"**{rec}**"
        + (" — " + " ".join(a["blockers"]) if a["blockers"] else ""))
    r, e = a["risk"], a["eligibility"]
    m = st.columns(4)
    m[0].metric("Risk score", f"{r['risk_score']:.1f}")
    m[0].markdown(ui.tier_badge(r["risk_tier"]), unsafe_allow_html=True)
    m[1].metric("Audit eligibility", e["eligibility_status"])
    m[2].metric("First audit due", e["next_due"] or "—", help=e["audit_type"] or "")
    m[3].metric("Data completeness", f"{a['data_quality']:.0%}")
    if r["overrides"]:
        st.caption("Override applied: " + "; ".join(r["overrides"]))
    if compact:
        return
    left, right = st.columns([1.1, 1])
    with left:
        st.markdown("**Duplicate check**")
        if not a["duplicates"]:
            st.markdown("✅ No existing supplier matches this name or tax ID.")
        for d in a["duplicates"]:
            icon = "⛔" if d["score"] >= ob.DUP_BLOCK else "⚠️"
            st.markdown(f"{icon} {d['legal_name']} ({d['golden_id']}) — {d['score']:.0f}% match by {d['method']}")
        st.markdown("**Questionnaire red flags** "
                    + (f"<span style='color:#888'>({'AI' if a['flag_source'] == 'ai' else 'keyword rules'})</span>"),
                    unsafe_allow_html=True)
        if a["red_flags"]:
            for f in a["red_flags"]:
                st.markdown(f"- 🚩 {ai.FLAG_LABEL.get(f, f)}")
        else:
            st.markdown("- None found")
        fac = pd.DataFrame(r["factors"].values()).sort_values("contribution")
        fig = go.Figure(go.Bar(x=fac.contribution, y=fac.label, orientation="h", marker_color="#2f6fdb",
                               text=[f"+{v:.1f}" for v in fac.contribution], textposition="outside",
                               hovertext=fac.detail))
        fig.update_layout(height=250, margin=dict(l=10, r=30, t=30, b=10), title="Risk factor contributions",
                          title_font_size=14)
        st.plotly_chart(fig, width="stretch")
    with right:
        st.markdown(f"**Eligibility · {e['eligibility_status']}**"
                    + (f" — {e['audit_type']} every {e['interval_months']} months" if e["eligible"] else ""))
        for x in e["reasons"]:
            st.markdown(f"- {x}")
        if e["scope"]:
            st.markdown("**Audit scope modules**")
            for s_ in e["scope"]:
                st.markdown(f"- {s_['name']} — _{s_['reason']}_")
        st.markdown("**Onboarding document checklist**")
        st.dataframe(pd.DataFrame([{"Document": x["item"], "Status": "✅ provided" if x["provided"] else "❌ missing"}
                                   for x in a["checklist"]]), hide_index=True, width="stretch")


# ---------------------------------------------------------------- New supplier
if view == "New supplier":
    editing = st.session_state.get("onb_editing")
    if editing:
        st.info(f"Completing onboarding request **{editing}**. Fill in the missing details, then run the checks.")
    ex = st.columns([1, 1, 1, 1.4])
    for i, name in enumerate(ob.EXAMPLES):
        if ex[i].button(f"Example: {name}", width="stretch"):
            to_state(ob.EXAMPLES[name])
            st.rerun()
    if ex[3].button("Clear form", width="stretch"):
        to_state({})
        st.rerun()

    with st.expander("📥 Bulk import onboarding requests from CSV or Excel"):
        st.caption("One supplier per row, using the form's field names as columns (see the *Field guide* sheet in "
                   "samples/onboarding/Onboarding_Requests_Sample.xlsx). Complete rows are assessed and submitted "
                   "for approval; rows with missing or invalid values join the queue as *Needs data*.")
        bf = st.file_uploader("Requests file", type=["csv", "xlsx", "xls"], key="onb_bulk_file")
        sample = SAMPLE_DIR / "Onboarding_Requests_Sample.xlsx"
        bc = st.columns([1, 1, 2])
        use_sample = sample.exists() and bc[0].button("Use the sample file", width="stretch")
        if sample.exists():
            bc[1].download_button("Download sample", sample.read_bytes(), sample.name, width="stretch")
        src = None
        if use_sample:
            src = (sample.name, sample.read_bytes())
        elif bf is not None and bc[2].button("Import requests", type="primary"):
            src = (bf.name, bf.getvalue())
        if src:
            name, data = src
            try:
                if name.lower().endswith(".csv"):
                    df = pd.read_csv(io.BytesIO(data), dtype=str, keep_default_na=False)
                else:
                    xl = pd.ExcelFile(io.BytesIO(data))
                    sheet = "Requests" if "Requests" in xl.sheet_names else xl.sheet_names[0]
                    df = xl.parse(sheet, dtype=str, keep_default_na=False)
                with st.spinner(f"Assessing {len(df)} suppliers…"):
                    st.session_state["onb_import"] = ob.import_requests(df, ui.user(), source=f"Bulk import ({name})")
                st.rerun()
            except Exception as exc:
                st.error(f"Could not import {name}: {exc}")
        res_imp = st.session_state.get("onb_import")
        if res_imp is not None and len(res_imp):
            n = res_imp.Result.value_counts().to_dict()
            st.success(f"Imported {len(res_imp)} rows: {n.get('Submitted', 0)} submitted for approval, "
                       f"{n.get('Needs data', 0)} need data, {n.get('Skipped', 0)} skipped. "
                       "Open the Onboarding queue to review them.")
            st.dataframe(res_imp, hide_index=True, width="stretch")

    countries = list(COUNTRIES)
    owners = [""] + people_with_role("supplier_owner")
    with st.form("onboard"):
        st.markdown("**Supplier details**")
        a1, a2, a3 = st.columns([2, 1, 1])
        a1.text_input("Legal name *", key=K + "legal_name")
        a2.text_input("Tax / registration ID", key=K + "tax_id")
        a3.selectbox("Country", countries, key=K + "country", format_func=lambda c: f"{COUNTRIES[c][0]} ({c})")
        b1, b2, b3 = st.columns([1.2, 1.2, 1])
        b1.selectbox("Category", list(CATEGORY_NAMES), key=K + "category_code", format_func=CATEGORY_NAMES.get)
        b2.text_input("Service provided", key=K + "service_type")
        b3.selectbox("Supplier owner", owners, key=K + "supplier_owner",
                     format_func=lambda x: x or "Assign automatically")
        st.markdown("**Risk profile**")
        c1, c2, c3, c4 = st.columns(4)
        c1.selectbox("Data access", ACCESS_ORDER, key=K + "data_access_level", format_func=ACCESS_LABEL.get)
        c2.number_input("Users with system access", min_value=0, step=1, key=K + "users_with_system_access")
        c3.selectbox("Business criticality", CRIT_ORDER, key=K + "criticality_tier", format_func=str.title)
        c4.number_input("Contractor headcount", min_value=0, step=1, key=K + "contractor_headcount")
        d1, d2, d3 = st.columns(3)
        d1.checkbox("Offshore delivery", key=K + "offshore_delivery")
        d2.checkbox("Uses sub-processors", key=K + "uses_subprocessors")
        d3.number_input("Questionnaire score (0–100)", min_value=0, max_value=100, step=1, key=K + "assessment_score",
                        help="Leave blank if not scored yet")
        st.markdown("**Contract and certification**")
        e1, e2, e3, e4, e5 = st.columns(5)
        e1.number_input("Annual contract value (INR)", min_value=0, step=100000, key=K + "contract_value_inr")
        e2.date_input("Contract start", key=K + "contract_start", format="YYYY-MM-DD")
        e3.date_input("Contract end", key=K + "contract_end", format="YYYY-MM-DD")
        e4.selectbox("Certification", list(CERTS), key=K + "certification", format_func=CERTS.get)
        e5.date_input("Certificate expiry", key=K + "certification_expiry", format="YYYY-MM-DD")
        st.markdown("**Security questionnaire**")
        st.text_area("Answers or comments", key=K + "questionnaire", height=110,
                     placeholder="Paste the supplier's questionnaire answers, or upload the file below")
        up = st.file_uploader("…or upload the questionnaire (TXT, MD, PDF, Word)", type=["txt", "md", "pdf", "docx"])
        go_ = st.form_submit_button("🔎 Run onboarding checks", type="primary")

    if go_:
        p = {f: st.session_state.get(K + f) for f in ob.DEFAULT}
        for f in ("contract_start", "contract_end", "certification_expiry"):
            p[f] = p[f].isoformat() if p[f] else None
        if up is not None:
            try:
                p["questionnaire"] = ((p["questionnaire"] or "") + "\n" + read_bytes(up.name, up.getvalue()).text).strip()
            except Exception as exc:
                st.error(f"Could not read the uploaded file: {exc}")
        with st.spinner("Checking duplicates, reading the questionnaire, scoring risk…"):
            st.session_state["onb_result"] = (p, ob.assess(p))

    res = st.session_state.get("onb_result")
    if res:
        p, a = res
        st.divider()
        st.subheader(f"Pre-onboarding assessment: {p['legal_name'] or '(unnamed)'}")
        show_assessment(a)
        if st.button("📨 Submit for approval", type="primary", disabled=not p.get("legal_name")):
            rid = ob.submit(p, ui.user(), request_id=st.session_state.get("onb_editing"))
            st.session_state["onb_result"] = None
            st.session_state["onb_editing"] = None
            st.session_state["onb_flash"] = f"Request {rid} submitted. The audit team can approve it in the queue."
            st.session_state["onb_pending"] = ({}, None)
            st.rerun()

# ---------------------------------------------------------------- Queue
elif view == "Onboarding queue":
    q = reqs[reqs.status.isin(["Needs data", "Submitted"])] if len(reqs) else reqs
    if not len(q):
        st.success("The onboarding queue is empty.")
        st.stop()
    rows = []
    for r in q.itertuples():
        p = ob.blank(**json.loads(r.payload))
        a = json.loads(r.assessment) if isinstance(r.assessment, str) else None
        rows.append({"Request": r.request_id, "Supplier": p["legal_name"], "Source": r.source, "Status": r.status,
                     "Tier": a["risk"]["risk_tier"] if a else "—",
                     "Eligibility": a["eligibility"]["eligibility_status"] if a else "—",
                     "Missing docs": str(len(a["missing_documents"])) if a else "—",
                     "Submitted by": r.submitted_by, "When": r.ts[:16].replace("T", " ")})
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
    pick = st.selectbox("Open request", q.request_id.tolist(),
                        format_func=lambda x: f"{x} · {next(r['Supplier'] for r in rows if r['Request'] == x)}")
    r = ob.get(pick)
    st.markdown(f"#### {r['payload']['legal_name']}  \n<span style='color:#888'>{r['request_id']} · {r['source']} · "
                f"{r['status']}</span>", unsafe_allow_html=True)
    if r["status"] == "Needs data":
        if r.get("note"):
            st.warning(f"Imported with problems: {r['note']}. Complete the details in the form to assess it.")
        else:
            st.warning("This vendor is in a source system but not in the supplier master. Complete its onboarding "
                       "details to assess it.")
        st.json({k: v for k, v in r["payload"].items() if v not in ("", None, 0, False)}, expanded=False)
        cA, cB = st.columns(2)
        if cA.button("✏️ Complete in form", type="primary"):
            to_state(r["payload"], r["request_id"])
            st.rerun()
        if ui.role() == "Audit team" and cB.button("Reject (not a supplier)"):
            ob.reject(r["request_id"], ui.user(), "Not a supplier to onboard")
            st.session_state["onb_flash"] = "Request rejected."
            st.rerun()
    else:
        show_assessment(r["assessment"])
        if ui.role() != "Audit team":
            st.caption("Only the audit team can approve or reject onboarding requests.")
        else:
            dup = any("duplicate" in b for b in r["assessment"]["blockers"])
            override = st.checkbox("Approve anyway (confirmed not a duplicate)") if dup else False
            note = st.text_input("Decision note (optional)")
            b1, b2, b3 = st.columns(3)
            if b1.button("✅ Approve and onboard", type="primary", disabled=dup and not override):
                with st.spinner("Onboarding and re-running the pipeline…"):
                    out = ob.approve(r["request_id"], ui.user(), override_duplicate=override)
                st.session_state["onb_flash"] = out["message"] + (
                    " Owners notified. Generate the audit plan from the Decided view." if out["ok"] else "")
                st.rerun()
            if b2.button("❌ Reject"):
                ob.reject(r["request_id"], ui.user(), note or "Rejected at onboarding review")
                st.session_state["onb_flash"] = "Request rejected."
                st.rerun()
            if b3.button("✏️ Edit details"):
                to_state(r["payload"], r["request_id"])
                st.rerun()

# ---------------------------------------------------------------- Decided
else:
    d = reqs[reqs.status.isin(["Approved", "Rejected"])] if len(reqs) else reqs
    if not len(d):
        st.info("No onboarding decisions yet.")
        st.stop()
    g = ui.golden().set_index("golden_id")
    rows = []
    for r in d.itertuples():
        p = json.loads(r.payload)
        gid = r.golden_id if isinstance(r.golden_id, str) else None
        gr = g.loc[gid] if gid in g.index else None
        rows.append({"Request": r.request_id, "Supplier": p.get("legal_name"), "Decision": r.status,
                     "Golden ID": gid or "—", "Tier": gr["risk_tier"] if gr is not None else "—",
                     "Score": round(float(gr["risk_score"]), 1) if gr is not None else None,
                     "Eligibility": gr["eligibility_status"] if gr is not None else "—",
                     "First audit due": gr["next_due"] if gr is not None and isinstance(gr["next_due"], str) else "—",
                     "Plan": "yes" if gid and len(active_plan(gid)) else "—",
                     "Decided by": r.decided_by, "Note": r.note or ""})
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
    todo = [x for x in rows if x["Decision"] == "Approved" and x["Eligibility"] == "Eligible" and x["Plan"] == "—"]
    if todo and ui.role() == "Audit team":
        sel = st.selectbox("Newly onboarded supplier without an audit plan", [x["Golden ID"] for x in todo],
                           format_func=lambda x: f"{x} · {next(t['Supplier'] for t in todo if t['Golden ID'] == x)}")
        if st.button("⚡ Generate audit plan", type="primary"):
            out = generate_plan(sel, ui.user())
            st.session_state["onb_flash"] = out["message"] + " Owners notified."
            st.session_state["selected"] = sel
            st.rerun()
    st.caption("Approved suppliers appear everywhere else in AuditPilot — Overview, Supplier 360, Audit planner — "
               "and stay in the supplier master on every rerun.")
