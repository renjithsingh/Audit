"""Builds the synthetic onboarding sample files in samples/onboarding/. All names and IDs are invented."""
from pathlib import Path

import pandas as pd

OUT = Path(__file__).resolve().parents[1] / "samples" / "onboarding"
OUT.mkdir(parents=True, exist_ok=True)

COLS = ["legal_name", "tax_id", "country", "category_code", "service_type", "data_access_level",
        "users_with_system_access", "criticality_tier", "contract_value_inr", "contract_start", "contract_end",
        "certification", "certification_expiry", "offshore_delivery", "uses_subprocessors", "contractor_headcount",
        "assessment_score", "supplier_owner", "questionnaire", "expected_outcome"]

ROWS = [
    ["Arclight Cloud Payments Pvt Ltd", "TXIN71200345", "IN", "84110000", "Payment processing", "pii", 60, "critical",
     320000000, "2026-12-01", "2029-11-30", "valid", "2027-03-31", "Y", "Y", 40, 74, "",
     "Cardholder and bank data processed for client employees. PCI DSS and ISO 27001 certified. MFA enforced for all "
     "admin access. Two sub-processors (cloud hosting, SMS gateway) listed in the DPA.",
     "Submitted - High risk (about 69), eligible; PII + offshore + sub-processors"],
    ["Brightpath Staffing Solutions Pvt Ltd", "TXIN64410921", "IN", "80110000", "Contract staffing", "pii", 25, "high",
     90000000, "2026-11-20", "2028-11-19", "expired", "2026-06-30", "N", "N", 120, 58, "",
     "Our contractors use client laptops. Background checks done for all staff. ISO certificate expired in June, "
     "recertification audit booked. Shared admin accounts still in use for the HR portal.",
     "Submitted - High risk (about 67), eligible; expired certificate and shared admin accounts flagged"],
    ["Northwind Freight Inc", "TXUS22019876", "US", "78100000", "Freight forwarding", "internal", 5, "medium",
     14000000, "2027-01-01", "2028-12-31", "valid", "2028-02-28", "N", "N", 0, 81, "",
     "Access limited to the shipment tracking portal. SOC 2 Type II report available.",
     "Submitted - Low risk (about 28), eligible because of system access"],
    ["Kestrel Guarding Services Ltd", "TXGB55302214", "GB", "92120000", "Site security", "confidential", 10, "high",
     22000000, "2026-12-15", "2028-12-14", "none", "", "N", "Y", 85, 64, "",
     "Guards have access to visitor logs and CCTV. No ISO certification. Incident response plan not documented. "
     "Sub-contracted night shift through a partner agency.",
     "Submitted - Medium risk (about 51), eligible; no certification, sub-processor documents required"],
    ["Sapphire Advisory GmbH", "TXDE80916634", "DE", "80100000", "Management consulting", "confidential", 8, "medium",
     30000000, "2026-11-25", "2027-11-24", "valid", "2027-09-30", "N", "N", 6, 79, "",
     "Consultants receive confidential strategy documents via the client data room. Encryption at rest and in transit.",
     "Submitted - Medium risk (about 41), eligible"],
    ["Halcyon Facility Care Pte Ltd", "TXSG30087712", "SG", "72100000", "Cleaning services", "none", 0, "low",
     2500000, "2026-12-01", "2027-11-30", "none", "", "N", "N", 30, 85, "",
     "Office cleaning only. Staff escorted in secure areas. No system or data access.",
     "Submitted - Low risk (about 11), monitor only, no audit"],
    ["Quill Print House Pvt Ltd", "TXIN90455128", "IN", "82120000", "Printing and stationery", "none", 0, "low",
     900000, "2026-11-15", "2027-11-14", "none", "", "N", "N", 0, 90, "",
     "We print and deliver stationery. No client data or system access.",
     "Submitted - Low risk (about 10), monitor only, no audit"],
    ["Tessera Data Labs Inc", "TXPH41870033", "PH", "43230000", "Data annotation", "pii", 80, "critical",
     150000000, "2026-12-10", "2029-12-09", "none", "", "Y", "Y", 200, 48, "",
     "Annotators label customer support transcripts containing personal data. MFA not in place for remote access. "
     "Backups not tested. Data stored in offshore data centre without client approval during peak periods.",
     "Submitted - Critical risk (about 82), eligible; several red flags from the questionnaire"],
    ["Orion Critical Systems Incorporated", "TXUS85529025", "US", "81110000", "Managed IT services", "pii", 40,
     "critical", 60000000, "2026-12-01", "2028-11-30", "none", "", "N", "Y", 25, 55, "",
     "Managed services for core platforms. Shared admin accounts still in use.",
     "Submitted - High risk; duplicate of Orion Critical Systems Inc (GS-0053, same tax ID), approval blocked"],
    ["Tandem IT Services Pvt Ltd", "TXIN11122233", "IN", "81110000", "Helpdesk support", "", "", "",
     12000000, "2027-01-15", "2028-01-14", "none", "", "Y", "N", 15, "", "",
     "", "Needs data - data access level and criticality missing"],
    ["Quasar Analytics Ltd", "TXGB77700451", "GB", "43230000", "Marketing analytics", "secret", 12, "high",
     18000000, "2026-12-01", "2027-11-30", "valid", "2027-05-31", "N", "Y", 4, 70, "",
     "Processes marketing contact lists.", "Needs data - 'secret' is not a valid data access level"],
    ["Vernal Translation Services Pvt Ltd", "TXIN50033190", "IN", "80100000", "Document translation",
     "confidential", 3, "medium", 4000000, "2026-11-20", "2027-11-19", "expired", "2026-08-31", "Y", "N", 12, 67, "",
     "Translators work remotely on confidential contracts. Annual security awareness training completed.",
     "Submitted - Medium risk (about 40), eligible; expired certificate"],
]

GUIDE = [
    ("legal_name", "Yes", "Registered legal name", "Arclight Cloud Payments Pvt Ltd"),
    ("tax_id", "Recommended", "Tax / registration ID; used for the duplicate check", "TXIN71200345"),
    ("country", "Yes", "ISO code or country name: IN, US, GB, DE, SG, PH", "IN"),
    ("category_code", "Yes", "UNSPSC code: 43230000 Software & data, 81110000 IT services, 78100000 Logistics, "
     "72100000 Facility management, 80100000 Consulting, 82120000 Printing, 80110000 HR & staffing, "
     "92120000 Security services, 84110000 Finance & payroll", "84110000"),
    ("service_type", "Yes", "What the supplier will do", "Payment processing"),
    ("data_access_level", "Yes", "none, internal, confidential or pii", "pii"),
    ("users_with_system_access", "No", "Supplier staff with access to our systems", "60"),
    ("criticality_tier", "Yes", "low, medium, high or critical", "critical"),
    ("contract_value_inr", "No", "Annual contract value in INR", "320000000"),
    ("contract_start", "No", "YYYY-MM-DD", "2026-12-01"),
    ("contract_end", "No", "YYYY-MM-DD", "2029-11-30"),
    ("certification", "No", "valid, expired or none (ISO 27001 / SOC 2)", "valid"),
    ("certification_expiry", "No", "YYYY-MM-DD", "2027-03-31"),
    ("offshore_delivery", "No", "Y or N", "Y"),
    ("uses_subprocessors", "No", "Y or N", "Y"),
    ("contractor_headcount", "No", "Supplier contractors on our engagement", "40"),
    ("assessment_score", "No", "Questionnaire score 0-100 (higher is better)", "74"),
    ("supplier_owner", "No", "Leave blank to assign automatically", ""),
    ("questionnaire", "No", "Security questionnaire answers; red flags are extracted from this text", "MFA enforced…"),
    ("expected_outcome", "No", "Ignored by the import; describes what the demo should show", ""),
]

QUESTIONNAIRES = {
    "Arclight_Security_Questionnaire": """Arclight Cloud Payments Pvt Ltd - Supplier Security Questionnaire (SYNTHETIC)

1. Certifications: ISO 27001 (expires 31 Mar 2027) and PCI DSS Level 1.
2. Data handled: cardholder data and employee bank details for client payroll payouts.
3. Access control: MFA enforced for all administrator and remote access. Quarterly access reviews.
4. Sub-processors: cloud hosting provider (Mumbai region) and an SMS gateway, both listed in the DPA.
5. Offshore delivery: second-line support from Singapore; no data stored outside India.
6. Backups: daily, restore tested every quarter.
7. Incident response: documented plan, 24-hour notification to clients.
8. Training: annual security awareness training completed by all staff.
""",
    "Tessera_Security_Questionnaire": """Tessera Data Labs Inc - Supplier Security Questionnaire (SYNTHETIC)

1. Certifications: none at present; ISO 27001 planned for next year.
2. Data handled: customer support transcripts that contain names, emails and phone numbers.
3. Access control: MFA not in place for remote access. Shared admin accounts still in use on the labelling tool.
4. Sub-processors: two freelance annotation agencies; no written approvals from clients.
5. Offshore delivery: annotation teams in Manila and Cebu. Data stored in offshore data centre without client
   approval during peak periods.
6. Backups: backups not tested this year.
7. Incident response: no documented plan; incidents handled by the operations lead.
8. Training: onboarding training only.
""",
    "Kestrel_Security_Questionnaire": """Kestrel Guarding Services Ltd - Supplier Security Questionnaire (SYNTHETIC)

1. Certifications: none.
2. Data handled: visitor logs, badge records and CCTV footage at client sites.
3. Access control: guards use a shared login on the visitor management kiosk.
4. Sub-processors: night shift sub-contracted to a partner agency.
5. Incident response: incident response plan not documented.
6. Training: annual security awareness training completed.
""",
}


def main() -> None:
    df = pd.DataFrame(ROWS, columns=COLS)
    df.to_csv(OUT / "Onboarding_Requests_Sample.csv", index=False)
    with pd.ExcelWriter(OUT / "Onboarding_Requests_Sample.xlsx", engine="openpyxl") as xw:
        df.to_excel(xw, sheet_name="Requests", index=False)
        pd.DataFrame(GUIDE, columns=["Column", "Required", "Meaning / allowed values", "Example"]).to_excel(
            xw, sheet_name="Field guide", index=False)
        for ws in xw.book.worksheets:
            for col in ws.columns:
                w = max(len(str(c.value or "")) for c in col)
                ws.column_dimensions[col[0].column_letter].width = min(max(12, w + 2), 60)
            ws.freeze_panes = "A2"
    for name, text in QUESTIONNAIRES.items():
        (OUT / f"{name}.txt").write_text(text, encoding="utf-8")
    from docx import Document
    d = Document()
    for i, line in enumerate(QUESTIONNAIRES["Arclight_Security_Questionnaire"].strip().splitlines()):
        d.add_heading(line, 1) if i == 0 else d.add_paragraph(line) if line.strip() else None
    d.save(OUT / "Arclight_Security_Questionnaire.docx")
    (OUT / "Arclight_Security_Questionnaire.txt").unlink()
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate
    ss = getSampleStyleSheet()
    lines = QUESTIONNAIRES["Tessera_Security_Questionnaire"].strip().splitlines()
    SimpleDocTemplate(str(OUT / "Tessera_Security_Questionnaire.pdf"), pagesize=A4).build(
        [Paragraph(lines[0], ss["Heading2"])] + [Paragraph(l, ss["Normal"]) for l in lines[1:] if l.strip()])
    (OUT / "Tessera_Security_Questionnaire.txt").unlink()
    print("Wrote", *sorted(p.name for p in OUT.iterdir()))


if __name__ == "__main__":
    main()
