"""Supplier onboarding: intake, instant pre-onboarding assessment, approval queue.

A new supplier is entered (or picked up from a source system where it is not yet in the supplier master),
checked for duplicates, risk-scored, given an eligibility / frequency / scope decision and an onboarding
document checklist, then approved or rejected by the audit team. Approved suppliers join the golden record
on every pipeline run, so the rest of AuditPilot (planner, tasks, notifications, analyst) treats them like
any other supplier.
"""
from __future__ import annotations

import json
import uuid
from datetime import date

import pandas as pd
from rapidfuzz import fuzz, process

from . import ai, audit_log, db
from .config import ACCESS_LABEL, RAW_DIR, people_with_role, rules as load_rules, today, weights as load_weights
from .consolidate import norm_country, norm_name
from .eligibility import evaluate
from .generate_data import CATEGORY_NAMES
from .risk import score_supplier

db.execute("""CREATE TABLE IF NOT EXISTS onboarding_requests(
  request_id TEXT PRIMARY KEY, ts TEXT, submitted_by TEXT, source TEXT, status TEXT, payload TEXT,
  assessment TEXT, golden_id TEXT, decided_by TEXT, decided_at TEXT, note TEXT)""")

STATUSES = ["Needs data", "Submitted", "Approved", "Rejected"]
FIRST_ID = 1001
DUP_BLOCK = 90      # likely the same supplier
DUP_WARN = 80       # possible duplicate

DEFAULT = {
    "legal_name": "", "tax_id": "", "country": "IN", "category_code": "43230000", "service_type": "",
    "data_access_level": "none", "users_with_system_access": 0, "criticality_tier": "medium",
    "contract_value_inr": 0, "contract_start": None, "contract_end": None, "certification": "none",
    "certification_expiry": None, "offshore_delivery": False, "uses_subprocessors": False,
    "contractor_headcount": 0, "assessment_score": None, "questionnaire": "", "supplier_owner": "",
}

EXAMPLES = {
    "High-risk data processor": {
        "legal_name": "Vantage Payroll Analytics Pvt Ltd", "tax_id": "TXIN55501234", "country": "IN",
        "category_code": "84110000", "service_type": "Payroll processing", "data_access_level": "pii",
        "users_with_system_access": 45, "criticality_tier": "high", "contract_value_inr": 180_000_000,
        "contract_start": "2026-12-01", "contract_end": "2029-11-30", "certification": "none",
        "certification_expiry": None, "offshore_delivery": True, "uses_subprocessors": True,
        "contractor_headcount": 60, "assessment_score": 62,
        "questionnaire": ("We process employee payroll data including bank details for client staff. "
                          "MFA rollout planned next year for remote access. Backups not tested this year. "
                          "Annual security awareness training completed. Data stored in offshore data centre "
                          "without client approval during peak periods."),
    },
    "Possible duplicate": {
        "legal_name": "NIMBUS DATA SERVICES PRIVATE LIMITED", "country": "IN", "category_code": "43230000",
        "service_type": "Data processing", "data_access_level": "pii", "users_with_system_access": 30,
        "criticality_tier": "high", "contract_value_inr": 25_000_000, "contract_start": "2026-11-15",
        "contract_end": "2028-11-14", "certification": "valid", "certification_expiry": "2028-10-11",
        "assessment_score": 70, "questionnaire": "Encryption at rest and in transit for client data.",
    },
    "Low-risk goods supplier": {
        "legal_name": "Meadow Office Furniture Pvt Ltd", "country": "IN", "category_code": "82120000",
        "service_type": "Office furniture", "data_access_level": "none", "users_with_system_access": 0,
        "criticality_tier": "low", "contract_value_inr": 1_200_000, "contract_start": "2026-11-15",
        "contract_end": "2027-11-14", "certification": "none", "assessment_score": 88,
        "questionnaire": "We deliver furniture only. We do not receive client data or system access.",
    },
}


def blank(**over) -> dict:
    return {**DEFAULT, **over}


def _owner(n: int, role: str) -> str:
    pool = people_with_role(role)
    return pool[n % len(pool)]


# ---------------------------------------------------------------- assessment
def _duplicates(p: dict, golden: pd.DataFrame) -> list[dict]:
    out = []
    if p.get("tax_id"):
        ariba = pd.read_csv(RAW_DIR / "ariba_suppliers.csv", dtype=str, keep_default_na=False)
        hit = ariba[ariba.tax_id == p["tax_id"].strip()]
        for a in hit.supplier_id.unique():
            gid = "GS-" + a.split("-")[1]
            r = golden[golden.golden_id == gid]
            if len(r):
                out.append({"golden_id": gid, "legal_name": r.iloc[0].legal_name, "score": 100.0,
                            "method": "same tax ID"})
    nn = norm_name(p.get("legal_name", ""))
    if nn:
        cand = golden[golden.country == p.get("country")] if p.get("country") else golden
        names = cand.legal_name.map(norm_name).tolist()
        for _n, sc, i in process.extract(nn, names, scorer=fuzz.token_sort_ratio, limit=3):
            if sc >= DUP_WARN:
                r = cand.iloc[i]
                if r.golden_id not in {d["golden_id"] for d in out}:
                    out.append({"golden_id": r.golden_id, "legal_name": r.legal_name, "score": round(sc, 1),
                                "method": "fuzzy name + country"})
    return sorted(out, key=lambda d: -d["score"])


def _checklist(p: dict) -> list[dict]:
    acc = p.get("data_access_level") or "none"
    crit = p.get("criticality_tier") or "medium"
    items = [
        ("Signed contract with dates", True, bool(p.get("contract_start") and p.get("contract_end"))),
        ("Tax / registration ID", True, bool(p.get("tax_id"))),
        ("Security questionnaire answered", True, bool((p.get("questionnaire") or "").strip())),
        ("ISO 27001 or SOC 2 report", acc in ("confidential", "pii") or (p.get("users_with_system_access") or 0) > 0,
         p.get("certification") == "valid"),
        ("Data processing agreement", acc == "pii", False),
        ("Sub-processor list and approvals", bool(p.get("uses_subprocessors")), False),
        ("Business continuity plan evidence", crit in ("high", "critical"), False),
        ("Offshore site security details", bool(p.get("offshore_delivery")), False),
    ]
    return [{"item": n, "required": req, "provided": got} for n, req, got in items if req]


def _quality(p: dict) -> float:
    keys = ["legal_name", "country", "category_code", "service_type", "data_access_level",
            "criticality_tier", "contract_value_inr", "contract_end", "certification", "assessment_score",
            "questionnaire", "tax_id"]
    ok = sum(1 for k in keys if p.get(k) not in (None, "", 0))
    return round(ok / len(keys), 2)


def to_golden_row(p: dict, gid: str, n: int) -> dict:
    cert = p.get("certification") or "none"
    exp = p.get("certification_expiry")
    if cert == "valid" and exp and date.fromisoformat(str(exp)) < today():
        cert = "expired"
    owner = p.get("supplier_owner") or _owner(n, "supplier_owner")
    return {
        "golden_id": gid, "ariba_id": f"ONB-{n}", "legal_name": p["legal_name"].strip(),
        "country": p.get("country"), "category_code": p.get("category_code"),
        "category_name": CATEGORY_NAMES.get(p.get("category_code"), "Other"),
        "service_type": p.get("service_type") or None,
        "contractor_headcount": float(p.get("contractor_headcount") or 0),
        "offshore_delivery": bool(p.get("offshore_delivery")), "data_access_level": p.get("data_access_level"),
        "users_with_system_access": float(p.get("users_with_system_access") or 0),
        "criticality_tier": p.get("criticality_tier"),
        "contract_value_inr": float(p.get("contract_value_inr") or 0) or None,
        "contract_start": p.get("contract_start"), "contract_end": p.get("contract_end"),
        "uses_subprocessors": bool(p.get("uses_subprocessors")), "certification_status": cert,
        "certification_detail": (f"ISO27001/SOC2 (exp {exp})" if cert != "none" else "None on file"),
        "certification_expiry": exp if cert != "none" else None,
        "assessment_score": float(p["assessment_score"]) if p.get("assessment_score") not in (None, "") else None,
        "assessment_comments": p.get("questionnaire") or "", "onboarding_date": today().isoformat(),
        "last_audit_date": None, "last_audit_rating": None, "open_critical": 0, "open_high": 0, "open_medium": 0,
        "audits_count": 0, "in_vms": False, "in_gbams": False, "in_pcm": False,
        "audit_owner": _owner(n, "audit_owner"), "supplier_owner": owner, "ism": _owner(n, "ism"),
        "data_quality": _quality(p), "pending_conflicts": 0,
    }


def assess(p: dict) -> dict:
    """Pre-onboarding assessment, computed by the same engines as every other supplier."""
    golden = db.read_table("golden")
    dups = _duplicates(p, golden)
    flags, flag_src = ai.extract_flags("NEW-SUPPLIER", p.get("questionnaire") or "")
    row = to_golden_row(p, "GS-NEW", 0)
    vals = golden.contract_value_inr.dropna().astype(float)
    v = row["contract_value_inr"]
    pct = float((vals < v).mean() * 100) if v and len(vals) else None
    w = load_weights()
    risk = score_supplier(row, pct, flags, w)
    row |= {"risk_score": risk["risk_score"], "risk_tier": risk["risk_tier"]}
    elig = evaluate(row, load_rules(), today())
    checklist = _checklist(p)
    missing = [c["item"] for c in checklist if not c["provided"]]
    blockers = []
    if not (p.get("legal_name") or "").strip():
        blockers.append("Legal name is required.")
    if dups and dups[0]["score"] >= DUP_BLOCK:
        blockers.append(f"Likely duplicate of {dups[0]['legal_name']} ({dups[0]['golden_id']}).")
    if p.get("contract_end") and p.get("contract_start") and p["contract_end"] < p["contract_start"]:
        blockers.append("Contract end is before contract start.")
    rec = ("Reject or merge: supplier already exists" if any("duplicate" in b for b in blockers) else
           "Approve after the missing documents are collected" if missing else "Ready to approve")
    return {"duplicates": dups, "red_flags": flags, "flag_source": flag_src,
            "risk": {k: risk[k] for k in ("risk_score", "raw_score", "risk_tier", "overrides", "factors",
                                          "low_confidence")},
            "eligibility": {k: elig[k] for k in ("eligible", "eligibility_status", "audit_type", "interval_months",
                                                  "next_due")}
            | {"reasons": json.loads(elig["eligibility_reasons"]), "scope": json.loads(elig["scope_modules"])},
            "checklist": checklist, "missing_documents": missing, "data_quality": row["data_quality"],
            "blockers": blockers, "recommendation": rec, "assessed_at": db.now(),
            "weights_version": w["version"]}


# ---------------------------------------------------------------- queue
def list_requests(status: str | None = None) -> pd.DataFrame:
    df = db.query("SELECT * FROM onboarding_requests ORDER BY ts DESC")
    return df[df.status == status] if status and len(df) else df


def get(request_id: str) -> dict | None:
    df = db.query("SELECT * FROM onboarding_requests WHERE request_id=?", (request_id,))
    if not len(df):
        return None
    r = df.iloc[0].to_dict()
    r["payload"] = json.loads(r["payload"])
    r["assessment"] = json.loads(r["assessment"]) if isinstance(r["assessment"], str) else None
    for k in ("golden_id", "decided_by", "decided_at", "note"):
        if not isinstance(r.get(k), str):
            r[k] = None
    return r


def submit(p: dict, actor: str, request_id: str | None = None, source: str = "Onboarding form") -> str:
    a = assess(p)
    rid = request_id or f"ONB-{today():%Y%m%d}-{uuid.uuid4().hex[:4].upper()}"
    exists = request_id and get(request_id)
    if exists:
        db.execute("UPDATE onboarding_requests SET payload=?, assessment=?, status='Submitted', ts=?, submitted_by=? "
                   "WHERE request_id=?", (json.dumps(p, default=str), json.dumps(a, default=str), db.now(), actor, rid))
    else:
        db.execute("INSERT INTO onboarding_requests(request_id, ts, submitted_by, source, status, payload, assessment)"
                   " VALUES (?,?,?,?,?,?,?)", (rid, db.now(), actor, source, "Submitted", json.dumps(p, default=str),
                                               json.dumps(a, default=str)))
    audit_log.log(actor, "onboarding_submitted", "onboarding_request", rid, None,
                  {"supplier": p.get("legal_name"), "tier": a["risk"]["risk_tier"],
                   "eligibility": a["eligibility"]["eligibility_status"], "missing": a["missing_documents"]})
    return rid


def seed_queue() -> int:
    """Vendors present in VMS but missing from the Ariba supplier master become 'Needs data' requests."""
    if db.get_meta("onboarding_seeded"):
        return 0
    m = db.read_table("matches")
    n = 0
    if len(m):
        vms = pd.read_csv(RAW_DIR / "vms_vendors.csv", dtype=str, keep_default_na=False).set_index("vendor_id")
        for r in m[(m.source == "VMS") & (m.status == "unmatched")].itertuples():
            v = vms.loc[r.source_id]
            p = blank(legal_name=v.vendor_name, country=norm_country(v.country) or "IN",
                      service_type="" if v.service_type == "Other" else v.service_type,
                      offshore_delivery=v.offshore_delivery == "Y",
                      contractor_headcount=int(v.contractor_headcount or 0))
            rid = f"ONB-VMS-{r.source_id.split('-')[1]}"
            db.execute("INSERT OR IGNORE INTO onboarding_requests(request_id, ts, submitted_by, source, status, payload)"
                       " VALUES (?,?,?,?,?,?)", (rid, db.now(), "system", f"VMS {r.source_id} (not in Ariba)",
                                                 "Needs data", json.dumps(p)))
            n += 1
    db.set_meta("onboarding_seeded", True)
    return n


def _next_number() -> int:
    df = db.query("SELECT golden_id FROM onboarding_requests WHERE golden_id IS NOT NULL")
    nums = [int(g.split("-")[1]) for g in df.golden_id] if len(df) else []
    return max(nums + [FIRST_ID - 1]) + 1


def approve(request_id: str, actor: str, override_duplicate: bool = False) -> dict:
    from .notifier import notify
    from .pipeline import run_all
    r = get(request_id)
    if not r or r["status"] != "Submitted":
        return {"ok": False, "message": "Only submitted requests can be approved."}
    a = assess(r["payload"])  # re-check against the current supplier master
    dup = [b for b in a["blockers"] if "duplicate" in b]
    other = [b for b in a["blockers"] if "duplicate" not in b]
    if other or (dup and not override_duplicate):
        return {"ok": False, "message": "Blocked: " + " ".join(other + dup)}
    n = _next_number()
    gid = f"GS-{n}"
    db.execute("UPDATE onboarding_requests SET status='Approved', golden_id=?, decided_by=?, decided_at=?, assessment=? "
               "WHERE request_id=?", (gid, actor, db.now(), json.dumps(a, default=str), request_id))
    audit_log.log(actor, "supplier_onboarded", "supplier", gid, None,
                  {"request": request_id, "supplier": r["payload"]["legal_name"], "tier": a["risk"]["risk_tier"],
                   "duplicate_override": bool(dup)})
    run_all(actor=actor)
    g = db.query("SELECT * FROM golden WHERE golden_id=?", (gid,)).iloc[0]
    notify("supplier_onboarded", [g.audit_owner, g.supplier_owner, g.ism], gid,
           {"supplier": g.legal_name, "gid": gid, "tier": g.risk_tier, "score": f"{g.risk_score:.1f}",
            "next_step": (f"First audit due {g.next_due} ({g.audit_type})." if g.eligible
                          else "No audit needed: monitor only.")},
           dedupe_key=f"onboarded:{gid}")
    return {"ok": True, "golden_id": gid, "eligible": bool(g.eligible), "tier": g.risk_tier,
            "score": float(g.risk_score), "message": f"Onboarded as {gid} · {g.risk_tier} ({g.risk_score:.1f}) · "
                                                     f"{g.eligibility_status}."}


def reject(request_id: str, actor: str, note: str = "") -> dict:
    r = get(request_id)
    if not r or r["status"] in ("Approved", "Rejected"):
        return {"ok": False, "message": "Request is already decided."}
    db.execute("UPDATE onboarding_requests SET status='Rejected', decided_by=?, decided_at=?, note=? WHERE request_id=?",
               (actor, db.now(), note, request_id))
    audit_log.log(actor, "onboarding_rejected", "onboarding_request", request_id, None,
                  {"supplier": r["payload"].get("legal_name"), "note": note})
    return {"ok": True, "message": "Request rejected."}


def approved_records() -> pd.DataFrame:
    """Golden-format rows for approved onboarding requests (added to the golden record on every run)."""
    df = db.query("SELECT golden_id, payload FROM onboarding_requests WHERE status='Approved' ORDER BY golden_id")
    rows = [to_golden_row(json.loads(r.payload), r.golden_id, int(r.golden_id.split("-")[1])) for r in df.itertuples()]
    return pd.DataFrame(rows)


def label(p: dict) -> str:
    return f"{p.get('legal_name') or '(unnamed)'} · {ACCESS_LABEL.get(p.get('data_access_level'), '?')}"


# ---------------------------------------------------------------- bulk import (CSV / Excel)
IMPORT_REQUIRED = ["legal_name", "country", "category_code", "service_type", "data_access_level", "criticality_tier"]
_BOOL = {"y": True, "yes": True, "true": True, "1": True, "n": False, "no": False, "false": False, "0": False}
_INT = ("users_with_system_access", "contractor_headcount", "contract_value_inr")
_DATE = ("contract_start", "contract_end", "certification_expiry")


def _clean(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    s = str(v).strip()
    return s or None


def row_to_payload(row: dict) -> tuple[dict, list[str]]:
    """Map one imported row to an onboarding payload. Returns the payload and its problems."""
    row = {str(k).strip().lower(): v for k, v in row.items()}
    p, problems = blank(), []
    for f in DEFAULT:
        v = _clean(row.get(f))
        if v is None:
            continue
        try:
            if f in _INT:
                p[f] = int(float(v.replace(",", "")))
            elif f == "assessment_score":
                p[f] = max(0, min(100, int(float(v))))
            elif f in ("offshore_delivery", "uses_subprocessors"):
                p[f] = _BOOL.get(v.lower(), False)
            elif f in _DATE:
                p[f] = pd.to_datetime(v).date().isoformat()
            elif f == "country":
                p[f] = norm_country(v) or v.upper()
            elif f == "category_code":
                p[f] = v.split(".")[0]
            elif f in ("data_access_level", "criticality_tier", "certification"):
                p[f] = v.lower()
            else:
                p[f] = v
        except (ValueError, TypeError):
            problems.append(f"{f}: could not read '{v}'")
    from .config import ACCESS_ORDER, CRIT_ORDER
    from .generate_data import COUNTRIES
    checks = [("data_access_level", ACCESS_ORDER), ("criticality_tier", CRIT_ORDER),
              ("certification", ["valid", "expired", "none"]), ("category_code", list(CATEGORY_NAMES)),
              ("country", list(COUNTRIES))]
    for f, allowed in checks:
        if p[f] not in allowed:   # invalid values are reported and reset so the form can still open the request
            problems.append(f"{f} '{p[f]}' is not one of {', '.join(allowed)}")
            p[f] = DEFAULT[f]
    for f in IMPORT_REQUIRED:
        if not _clean(row.get(f)):
            problems.append(f"{f} is missing")
    return p, problems


def import_requests(df: pd.DataFrame, actor: str, source: str = "Bulk import") -> pd.DataFrame:
    """Complete rows are submitted for approval; incomplete ones join the queue as 'Needs data'."""
    out = []
    for i, row in enumerate(df.to_dict("records"), start=2):
        p, problems = row_to_payload(row)
        if not p.get("legal_name"):
            out.append({"Row": i, "Supplier": "", "Result": "Skipped", "Request": "", "Detail": "legal_name is missing"})
            continue
        if problems:
            rid = f"ONB-{today():%Y%m%d}-{uuid.uuid4().hex[:4].upper()}"
            db.execute("INSERT INTO onboarding_requests(request_id, ts, submitted_by, source, status, payload, note)"
                       " VALUES (?,?,?,?,?,?,?)", (rid, db.now(), actor, source, "Needs data",
                                                   json.dumps(p, default=str), "; ".join(problems)))
            audit_log.log(actor, "onboarding_imported", "onboarding_request", rid, None,
                          {"supplier": p["legal_name"], "status": "Needs data", "problems": problems})
            out.append({"Row": i, "Supplier": p["legal_name"], "Result": "Needs data", "Request": rid,
                        "Detail": "; ".join(problems)})
        else:
            rid = submit(p, actor, source=source)
            a = get(rid)["assessment"]
            a = json.loads(a) if isinstance(a, str) else a
            out.append({"Row": i, "Supplier": p["legal_name"], "Result": "Submitted", "Request": rid,
                        "Detail": f"{a['risk']['risk_tier']} risk {a['risk']['risk_score']} · "
                                  f"{a['eligibility']['eligibility_status']}"
                                  + (" · possible duplicate" if a["duplicates"] else "")})
    return pd.DataFrame(out)
